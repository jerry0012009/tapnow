(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,t={enabled:!0,gateClicks:!0,requiredTerms:[],forbiddenTerms:[],llmEnabled:!1,llmProtocol:`responses`,llmModel:`gpt-4o-mini`,llmBaseUrl:`https://api.openai.com/v1`};function n(e){return Array.isArray(e)?e.map(e=>String(e).trim()).filter(Boolean):String(e??``).split(/[,，\n]/).map(e=>e.trim()).filter(Boolean)}function r(e={}){return{enabled:e.enabled!==!1,gateClicks:e.gateClicks!==!1,requiredTerms:n(e.requiredTerms),forbiddenTerms:n(e.forbiddenTerms),llmEnabled:e.llmEnabled===!0,llmProtocol:e.llmProtocol===`chat_completions`?`chat_completions`:`responses`,llmModel:String(e.llmModel||t.llmModel).trim(),llmBaseUrl:String(e.llmBaseUrl||t.llmBaseUrl).trim().replace(/\/+$/,``)}}var i=document.querySelector(`#app`);i.innerHTML=`
  <style>
    :root { color-scheme: light; font-family: system-ui, -apple-system, sans-serif; }
    body { width: 330px; margin: 0; padding: 16px; color: #0f172a; background: #f8fafc; }
    h1 { margin: 0 0 4px; font-size: 17px; }
    p { margin: 0 0 14px; color: #64748b; font-size: 12px; line-height: 1.4; }
    label { display: block; margin: 12px 0 6px; font-size: 12px; font-weight: 700; color: #475569; }
    input[type="text"], input[type="password"], textarea, select { box-sizing: border-box; width: 100%; padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px; background: white; font: 13px/1.4 system-ui, sans-serif; }
    textarea { min-height: 52px; resize: vertical; }
    .row { display: flex; align-items: center; gap: 8px; font-size: 13px; }
    .row label { margin: 0; font-weight: 600; color: #0f172a; }
    button { width: 100%; margin-top: 14px; min-height: 36px; border: 0; border-radius: 6px; background: #2563eb; color: white; font: 600 13px system-ui, sans-serif; cursor: pointer; }
    .section { border-top: 1px solid #e2e8f0; margin-top: 15px; padding-top: 3px; }
    .hint { color: #64748b; font-size: 11px; line-height: 1.4; margin-top: 5px; }
    #status { min-height: 18px; margin-top: 8px; color: #15803d; font-size: 12px; }
  </style>
  <h1>TapNow Companion 0.1</h1>
  <p>运行前审核。页面脚本不读取 Token；API Key 仅保存在本机扩展存储。</p>
  <div class="row"><input id="enabled" type="checkbox"><label for="enabled">启用副驾驶</label></div>
  <div class="row"><input id="gateClicks" type="checkbox"><label for="gateClicks">拦截运行/生成按钮</label></div>
  <label for="requiredTerms">团队要求词（逗号或换行分隔）</label>
  <textarea id="requiredTerms" placeholder="例如：电影感, 品牌色"></textarea>
  <label for="forbiddenTerms">团队禁用词（逗号或换行分隔）</label>
  <textarea id="forbiddenTerms" placeholder="例如：未授权品牌"></textarea>
  <div class="section">
    <div class="row"><input id="llmEnabled" type="checkbox"><label for="llmEnabled">启用 LLM 审阅</label></div>
    <label for="llmProtocol">接口协议</label>
    <select id="llmProtocol">
      <option value="responses">Responses</option>
      <option value="chat_completions">Chat Completions</option>
    </select>
    <label for="llmModel">模型</label>
    <input id="llmModel" type="text" placeholder="gpt-4o-mini">
    <label for="llmBaseUrl">API Base URL</label>
    <input id="llmBaseUrl" type="text" placeholder="https://api.openai.com/v1">
    <label for="apiKey">API Key</label>
    <input id="apiKey" type="password" placeholder="留空表示不修改已保存的 Key">
    <div class="hint">0.1 只允许 OpenAI 官方 HTTPS API；Key 不会同步到 Chrome 账号。</div>
  </div>
  <button id="save" type="button">保存设置</button>
  <div id="status" role="status"></div>
`;var a=e=>document.getElementById(e),[o,s]=await Promise.all([e.storage.sync.get(t),e.storage.local.get({apiKey:``})]),c=r(o);a(`enabled`).checked=c.enabled,a(`gateClicks`).checked=c.gateClicks,a(`llmEnabled`).checked=c.llmEnabled,a(`llmProtocol`).value=c.llmProtocol,a(`llmModel`).value=c.llmModel,a(`llmBaseUrl`).value=c.llmBaseUrl,a(`requiredTerms`).value=c.requiredTerms.join(`, `),a(`forbiddenTerms`).value=c.forbiddenTerms.join(`, `),a(`apiKey`).placeholder=s.apiKey?`已配置，留空表示不修改`:`sk-...`,a(`save`).addEventListener(`click`,async()=>{let t=r({enabled:a(`enabled`).checked,gateClicks:a(`gateClicks`).checked,llmEnabled:a(`llmEnabled`).checked,llmProtocol:a(`llmProtocol`).value,llmModel:a(`llmModel`).value,llmBaseUrl:a(`llmBaseUrl`).value,requiredTerms:a(`requiredTerms`).value,forbiddenTerms:a(`forbiddenTerms`).value}),n=a(`apiKey`).value.trim();await e.storage.sync.set(t),n&&await e.storage.local.set({apiKey:n}),a(`status`).textContent=`已保存。刷新 TapNow 页面后生效。`});