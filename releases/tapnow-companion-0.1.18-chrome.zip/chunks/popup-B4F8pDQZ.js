(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,t=272e3,n=2e5,r=2e4,i=28e6,a=[`审阅一个创作节点，帮助用户在运行前发现质量、上下文和团队风格问题。`,`用户消息中的 image-1、image-2 等文字标记紧跟对应图片，必须按编号引用图片，不要混淆素材；reference_bindings 是提示词中的 Image N 与实际素材的对应关系。`,`focus_node.prompt 是当前节点输入，focus_node.text 是当前节点生成产物；上游 text 节点只使用其生成产物 text，不要把上游人工 prompt 当成本次输入。`,`当 prompt_source 为 direct-upstream-text-output 时，prompt 是直接上游 Text 节点的生成产物；不要把 prompt_candidates 中被标记为忽略的哈希、UUID 或人工输入当作本次提示词。`,`incoming_nodes 和 incoming_connections 是当前节点的直接关系；outgoing_nodes 和 outgoing_connections 是当前节点的后续关系。`,`只输出符合 JSON schema 的结果；不要改写原提示词，不要编造未提供的上下文。`,`decision 只能是 allow、warn、block；普通质量问题用 warn，明显无法运行或违反规则用 block。`].join(` `),o={enabled:!0,requiredTerms:[],forbiddenTerms:[],llmEnabled:!1,llmIncludeImages:!1,llmPrompt:a,llmProtocol:`responses`,llmModel:`gpt-5.6-luna`,llmBaseUrl:`https://api.acucompute.com/v1`};function s(e){return Array.isArray(e)?e.map(e=>String(e).trim()).filter(Boolean):String(e??``).split(/[,，\n]/).map(e=>e.trim()).filter(Boolean)}function c(e={}){return{enabled:e.enabled!==!1,requiredTerms:s(e.requiredTerms),forbiddenTerms:s(e.forbiddenTerms),llmEnabled:e.llmEnabled===!0,llmIncludeImages:e.llmIncludeImages===!0,llmPrompt:String(e.llmPrompt||a).trim().slice(0,r),llmProtocol:e.llmProtocol===`chat_completions`?`chat_completions`:`responses`,llmModel:String(e.llmModel||o.llmModel).trim(),llmBaseUrl:String(e.llmBaseUrl||o.llmBaseUrl).trim().replace(/\/+$/,``)}}var l=document.querySelector(`#app`);l.innerHTML=`
  <style>
    :root { color-scheme: light; font-family: system-ui, -apple-system, sans-serif; }
    body { width: 330px; margin: 0; padding: 16px; color: #0f172a; background: #f8fafc; }
    h1 { margin: 0 0 4px; font-size: 17px; }
    p { margin: 0 0 14px; color: #64748b; font-size: 12px; line-height: 1.4; }
    label { display: block; margin: 12px 0 6px; font-size: 12px; font-weight: 700; color: #475569; }
    input[type="text"], input[type="password"], textarea, select { box-sizing: border-box; width: 100%; padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px; background: white; font: 13px/1.4 system-ui, sans-serif; }
    textarea { min-height: 52px; resize: vertical; }
    .row { display: flex; align-items: center; gap: 8px; font-size: 13px; }
    .row label { margin: 0; font-weight: 600; color: #0f172a; }
    button { width: 100%; margin-top: 14px; min-height: 36px; border: 0; border-radius: 6px; background: #2563eb; color: white; font: 600 13px system-ui, sans-serif; cursor: pointer; }
    .section { border-top: 1px solid #e2e8f0; margin-top: 15px; padding-top: 3px; }
    .hint { color: #64748b; font-size: 11px; line-height: 1.4; margin-top: 5px; }
    #status { min-height: 18px; margin-top: 8px; color: #15803d; font-size: 12px; }
  </style>
  <h1>TapNow Companion 0.1</h1>
  <p>TapNow 节点审阅</p>
  <div class="row"><input id="enabled" type="checkbox"><label for="enabled">启用副驾驶</label></div>
  <label for="requiredTerms">团队要求词（逗号或换行分隔）</label>
  <textarea id="requiredTerms" placeholder="例如：电影感, 品牌色"></textarea>
  <label for="forbiddenTerms">团队禁用词（逗号或换行分隔）</label>
  <textarea id="forbiddenTerms" placeholder="例如：未授权品牌"></textarea>
    <div class="section">
      <div class="row"><input id="llmEnabled" type="checkbox"><label for="llmEnabled">启用 LLM 审阅</label></div>
      <div class="row"><input id="llmIncludeImages" type="checkbox"><label for="llmIncludeImages">检测时发送图片素材</label></div>
    <label for="llmPrompt">LLM 审阅提示词</label>
    <textarea id="llmPrompt" maxlength="${r}" placeholder="用于指导模型审阅当前节点，只输出 JSON 结果。"></textarea>
    <div class="hint">检测时作为 system/instructions 发送，最多 ${r.toLocaleString()} 字符。</div>
    <div class="hint">ACU gpt-5.6 目录标注 ${t.toLocaleString()} tokens；节点文字总预算 ${n.toLocaleString()} 字符，请求体预算 ${(i/1e6).toFixed(0)} MB。</div>
    <label for="llmProtocol">接口协议</label>
    <select id="llmProtocol">
      <option value="responses">Responses</option>
      <option value="chat_completions">Chat Completions</option>
    </select>
    <label for="llmModel">模型</label>
    <input id="llmModel" type="text" placeholder="gpt-5.6-luna">
    <label for="llmBaseUrl">API Base URL</label>
    <input id="llmBaseUrl" type="text" placeholder="https://api.acucompute.com/v1">
    <label for="apiKey">API Key</label>
    <input id="apiKey" type="password" placeholder="留空表示不修改已保存的 Key">
    <div class="hint">0.1 支持 OpenAI/ACU HTTPS API；Key 不会同步到 Chrome 账号。</div>
  </div>
  <button id="save" type="button">保存设置</button>
  <div id="status" role="status"></div>
`;var u=e=>document.getElementById(e),[d,f]=await Promise.all([e.storage.sync.get(o),e.storage.local.get({apiKey:``})]),p=c(d);u(`enabled`).checked=p.enabled,u(`llmEnabled`).checked=p.llmEnabled,u(`llmIncludeImages`).checked=p.llmIncludeImages,u(`llmPrompt`).value=p.llmPrompt,u(`llmProtocol`).value=p.llmProtocol,u(`llmModel`).value=p.llmModel,u(`llmBaseUrl`).value=p.llmBaseUrl,u(`requiredTerms`).value=p.requiredTerms.join(`, `),u(`forbiddenTerms`).value=p.forbiddenTerms.join(`, `),u(`apiKey`).placeholder=f.apiKey?`已配置，留空表示不修改`:`sk-...`,u(`save`).addEventListener(`click`,async()=>{let t=c({enabled:u(`enabled`).checked,llmEnabled:u(`llmEnabled`).checked,llmIncludeImages:u(`llmIncludeImages`).checked,llmPrompt:u(`llmPrompt`).value,llmProtocol:u(`llmProtocol`).value,llmModel:u(`llmModel`).value,llmBaseUrl:u(`llmBaseUrl`).value,requiredTerms:u(`requiredTerms`).value,forbiddenTerms:u(`forbiddenTerms`).value}),n=u(`apiKey`).value.trim();await e.storage.sync.set(t),n&&await e.storage.local.set({apiKey:n}),u(`status`).textContent=`已保存。刷新 TapNow 页面后生效。`});